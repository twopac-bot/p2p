lst = [10, 20, 30, 40]

x = int(input("Enter element: "))

if x in lst:
    print("Index:", lst.index(x))
else:
    print("Element not found")
