lst = [10, 5, 20, 8, 15]

largest = max(lst)

lst.remove(largest)

print(max(lst))