lst = [1, 2, 3, 4, 5]

x = int(input("Enter element to remove: "))

if x in lst:
    lst.remove(x)
    print("Updated list:", lst)
else:
    print("Element not found")
