lst = [1, 2, 3, 4]

x = int(input("Enter element to add: "))
lst.append(x)

print("Updated list:", lst)
