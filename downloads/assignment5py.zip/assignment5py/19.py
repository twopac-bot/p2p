def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

lst = [2, 4, 5, 6, 7, 8, 11]

prime_tuple = tuple([x for x in lst if is_prime(x)])

print("Prime tuple:", prime_tuple)
