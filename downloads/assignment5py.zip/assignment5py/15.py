lst = [1, 2, 2, 3, 4, 4, 5]

new_list = []

for i in lst:
    if i not in new_list:
        new_list.append(i)

result = tuple(new_list)

print("Tuple without duplicates:", result)
