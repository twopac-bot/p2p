list = [1,2,3,4,5]

tp = tuple(list)

print(tp)