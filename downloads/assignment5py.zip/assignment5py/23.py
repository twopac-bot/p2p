lst = [(1, 3), (2, 1), (4, 2)]

lst.sort(key=lambda x: x[1])

print("Sorted list:", lst)
