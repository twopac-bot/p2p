tp = (1,2,1,1,1,3,4,5,68,8)

num = int(input("enter a number:"))
count = tp.count(num)

print(count)