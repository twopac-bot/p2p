ls = (1,2,3,4,5,6)
count = 0
for i in ls:
    count+=1

print(count)