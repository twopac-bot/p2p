t = (1, 2, 3, 5, 6, 7, 8, 2, 3)

max_len = 1
current_len = 1

for i in range(1, len(t)):
    if t[i] == t[i - 1] + 1:
        current_len += 1
        max_len = max(max_len, current_len)
    else:
        current_len = 1

print("Longest length:", max_len)
