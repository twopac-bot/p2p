l1 = [1, 2, 3, 4]
l2 = [3, 4, 5, 6]

intersection = []
union = []

for i in l1:
    if i not in union:
        union.append(i)

for i in l2:
    if i in l1 and i not in intersection:
        intersection.append(i)
    if i not in union:
        union.append(i)

print("Intersection:", intersection)
print("Union:", union)
