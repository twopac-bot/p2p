ls = [1,2,3,4,5,5,5,5,6]

temp = []
def search(ls,a):
    for i in ls:
        if i == a:
            return True
            break
    return False

for i in ls:
    if not search(temp,i):
        temp.append(i)
    else:
        continue

ls = temp
print(ls)