ls = [1,2,3,4,5,7,6]
ls.sort()
c=int(input("enter a number to search: "))

low = 0
high = len(ls)-1

flg = 1
while low<=high:
    mid = (low+high)//2
    if ls[mid]==c:
        print("found")
        flg = 0
        break
    elif ls[mid]>c:
        high = mid-1
    else:
        low = mid+1

if flg:
    print("not found")