my_dict = {"name": "Aditya"}

my_dict.setdefault("age", 20)
my_dict.setdefault("name", "NewName")  

my_dict[1] = 3
my_dict.pop(1)
print(my_dict)

