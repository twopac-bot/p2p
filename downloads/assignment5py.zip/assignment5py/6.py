t = (10, 20, 30, 40, 50)

x = int(input("Enter element to search: "))

if x in t:
    print("Element exists in tuple")
else:
    print("Element does not exist")
