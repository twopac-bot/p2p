tp = (1,2,3,4,5)

ls = list(tp)

print(ls)